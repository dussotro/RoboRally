# -bug-free-waffle
#Avancement_Global#
1-Robots/Terrain/Joueur_Humain --> Fait
2-GUI pour visualisation --> Fait
#Mode d'emploi#
1-lancer le script Fonctions pour Demo
#To-do list#
1-Creation d'IA (on utilisera l'héritage avec un classe abstraite joueur) et on redéfinira la methode make_menu() pour joueur/IA
2-Classe Partie (Qui prends en entrée Terrain,JoueurS,RobotS) qui administre la partie et permettra de tester les IA
Priorités : IA Random
3-Réaliser le GUI
