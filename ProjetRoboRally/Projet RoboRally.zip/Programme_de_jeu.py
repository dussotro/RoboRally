# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 10:26:38 2017

@author: Romain
"""
import random as rd
import plateau as pl
import Definition_Classe as cl

"""""""""""""""
Fonctions
"""""""""""""""

def Initialisation(nb_joueur, nb_IA):
    #définition des joueurs     
    global Joueur
    Joueur = []
    global Bot
    Bot = []
    #définition du plateau
    plateau = pl.Map('fichier.txt', 'r')
    #ajout des utilisateurs
    for i in range(nb_joueur):
        Joueur.append(cl.Utilisateur(plateau))
    for  j in range(nb_IA):
        Bot.append(cl.IA(plateau))
    









